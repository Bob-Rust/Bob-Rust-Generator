console.log('Initializing!');

var a = require('./x64/Release/BorstPrimitive');
console.log('Value: ' + a);